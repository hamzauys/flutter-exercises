class LanguageItems {
  static const welcomeTitle = "Merhaba";
}